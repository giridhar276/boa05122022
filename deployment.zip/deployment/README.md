# machine_learning_model_using_flask_web_framework
This repository contains the whole process to build a machine learning model using python and also explain the steps to deploy it using Flask web framework.
