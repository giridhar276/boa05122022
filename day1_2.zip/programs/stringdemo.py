


val = 10
print(val)
print("The value is ", val)



name  = "python"
print("I love",name)


# slicing
# string[start:stop:step]
name = "python programming"
print(name)
print(name[0])
print(name[1])
print(name[0:5])
print(name[7:9])
print(name[:8])
print(name[8:])
print(name[:])
print(name[::])
print(name[::1])
print(name[::-1])

print(name[0:18:2])
print(name[0:18:3])
print(name[1:18:2])
print(name[-1])
print(name[-2])
print(name[-3])
print(name[-4:-1])
print(name[-1:-4:-1])
print(name[::-1])





name = "python programming"
print(name.capitalize())
print(name.count('p'))
print(name.upper())
print(name.lower())
print(name.startswith('p'))
print(name.startswith('l'))
print(name.endswith('g'))
print(name.endswith('h'))
print(name.isupper())
print(name.islower())
print(name.replace('python', 'java'))
print(name)
print(len(name))  # length of the string
print(name.center(40))
print(name.center(40,"*"))
print(name.split(" "))
aname = " python  "
print(len(aname))
print(len(aname.strip())) # remove whitespace at both ends
print(len(aname.lstrip()))
print(len(aname.rstrip()))
name = "python programming"
print(name.find('o'))
print(name.find('z'))
print(name.count('o'))
print(name.index('o')) # will display the index number
query = "I love {} and {}"  # skeleton  # template
print(query.format('unix','scala'))
print(query.format('java','scala'))
query = "I love {0} and {1}"
print(query.format('unix','scala'))
print(query.format('java','scala'))
query = "I love {1} and {0}"
print(query.format('unix','scala'))
print(query.format('java','scala'))




print(name)
print(name.startswith('p'))


## simple if
if name.startswith('p'):
    print('Python programming')
    print('inside if')
    print("Still inside if")
print('regular program')

# if-else
if name.startswith('p'):
    print('Python programming')
    print('inside if')
else:
    print('someother language')
    print('inside else')

#if-elif-elif-elif... else
if name.startswith('p'):
    print('Python programming')
elif name.startswith('j'):
    print('java programming')
elif name.startswith('r'):
    print('ruby programming')
else:
    print('its tool')



if name.isupper():
    print('string is upper')
elif name.islower():
    print('string is lower')
elif name.isalnum():
    print("string as both alphas and numerics")
else:
    print('something else')
    
    
name = 'python'
print(name)
    
# for loop  # range(start,stop,step)
for val in range(1,11):
    print(val)
    
for val in range(2,11,2):
    print(val)
    
for val in range(11,0,-1):
    print(val)
    
name = 'python'
for char in name:
    print(char)
    
alist = [10,20,30]
alist.reverse()
for val in alist:
    print(val)
    
    
    
i = 1
while i <=10:
    print(i)
    i= i + 1
    
    
    
    
    
    
name = "python"

for char in name:
    if char == 'h':
        break
    print(char)    
    
    
    
    
    
    
    








