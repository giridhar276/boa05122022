book = {"chap1":10 ,"chap2":20 ,"chap3":30}
print(book)           # will display all key,values
print(book['chap1'])  # 10

book = {"chap1":10 ,"chap2":20 ,"chap3":30,"chap1":100}
print(book)

book["chap4"] = 40    ## add new key-value pair
print(book)

book["chap4"] = 50     ## add new key-value pair
print(book)
## display all the keys
print(book.keys())

for key in book.keys():
    print(key)
# display all the values
print(book.values())

for value in book.values():
    print(value)
# display key,value
for key,value in book.items():
    print(key,value)
book.pop('chap1')
print('After pop :', book)

book.popitem()
print('After popitem :', book)

book.popitem()
print('After popitem :', book)

del book['chap2']
print('After delting:', book)


