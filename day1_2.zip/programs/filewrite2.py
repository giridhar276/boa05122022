

# traditional way  # legacy way
fw = open("languages.txt","w")
fw.write('python\n')
fw.write('scala\n')
fw.close()



# context manager
# file gets closed automatically
# if any line starts with keyword with.. we call it as context manager
with open("languages.txt","w") as fw:
    fw.write('python\n')
    fw.write('scala\n')


    
