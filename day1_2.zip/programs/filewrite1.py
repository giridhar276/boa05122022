#paramiko
# if the file is not existing.. new file gets created first
# if the file is already existing.. it overwrites the existing content
fw = open("languages.txt","w")
fw.write('python\n')
fw.rite('scala\n')
fw.close()


fw = open("numbers.txt","w")
for val in range(1,10):
    fw.write( str(val) + "\n")
fw.close()

# If file has to be created in different path
#fw = open("C:/Users/Administrator/Desktop/numbers.txt","w")   #or
#fw = open(r"C:\Users\Administrator\Desktop\numbers.txt","w")   # raw string
fw = open("C:\\Users\\Administrator\\Desktop\\numbers.txt","w")
for val in range(1,10):
    fw.write( str(val) + "\n")
fw.close()