
#method1
# all the methods will be imported to your program space
import math
print(math.floor(2.34))
print(math.log(2))

#method2 - creating alias name
import math as m
print(m.log(1))
print(m.tan(2))


#method3 - importing required methods only
from math import log,floor,ceil,sin
print(log(1))
print(floor(34.2))
print(ceil(87.1))


