# reading the file line by line# fobj acts like cursor or pointer or reference to the file
with open("languages.txt","r") as fobj:
    for line in fobj:
        # to remove whitespaces if any
        line = line.strip()
        print(line)
    
# reading using fobj.readlines()  ---> output in list 
with open("languages.txt","r") as fobj:
    print(fobj.readlines())
    
    
with open("languages.txt","r") as fobj:
    for line in fobj.readlines():
        print(line)
    
# reading with fobj.read()   ----> return single string
with open("languages.txt","r") as fobj:
    print(fobj.read())
    
# using csv library  # Advantage: each lin will be automatically converted to list
import csv
with open("languages.txt","r") as fobj:
    # convert file object to csv object
    reader = csv.reader(fobj)
    for line in reader:
        print(line)
    
    