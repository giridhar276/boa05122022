try:
    filename = input('Enter any filename :')
    with open(filename) as fobj:
        for line in fobj:
            print(line)

except IndexError as error:
    print(error)

except FileNotFoundError as e:
    print(e)
    print("file not found")
except KeyError as err:
    print(err)
    print("dictionary key is not found")
except (TypeError,ValueError,EOFError) as err:
    print(err)
except Exception as err:
    print('Unknown error')
print('regular code')
        
        
        
        
        
print(1 + "hello")


alist = [10,20,30]
print(alist[10])

book = {"chap1":10,"chap2":20}
print(book["chap3"])