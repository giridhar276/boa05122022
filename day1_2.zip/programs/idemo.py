name = 'python programming'
getcount = name.count('prog')
if getcount == 0:
    print("substring doesn't exist")
    
name = "python programming"
if 'gram' in name:
    print("Exists")
else:
    print('doesnt exist')
     
alist = [10,20,30,40]
if 30 in alist:
    print('do something')
    
book = {"chap1":10 ,"chap2":20 ,"chap3":30}
if 'chap1' in book:
    print('do something')
        
name  = 'python'
print(name * 5)
alist = [10,20,30]
print(alist * 3)
print( 3 + 4)
print("python" + " " + "programming")
print([10,20] + [30,40])
    
print([10,20] + list((30,40)))
    