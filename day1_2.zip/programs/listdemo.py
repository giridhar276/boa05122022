alist = [10,20,30,4,3,32,17,34]
print("list elements are ", alist)
alist.append(93)  ## single object
print("After appending :",alist)
alist.append(51)
print("After appending :",alist)
alist.extend([18,73,1,35]) ## pass multiple values
print('After extending:',alist)
alist.insert(2,25) ## list.insert(index,value)
print('After inserting :',alist)
#list.pop(index)
alist.pop()  # if index is not passed,last value wil be removed
print('After pop',alist)
alist.pop(2)
print('After pop',alist)
if 100 in alist:
    alist.remove(100)   # used to remove the value directly
    print('After remove :',alist)
alist.sort()   # sorting happens in place
print('After sorting :',alist)
alist.sort(reverse=True)   # sorting happens in place
print('After sorting :',alist)
alist.reverse() # reverse happens in place
print('After reversing :',alist)



alist = [10,10,10,20,30,40,50]
print(set(alist))

alist.remove(10)


# remove all the occurences of 10
for val in range(0,alist.count(10)):
    alist.remove(10)
print(alist)

# list.insert(index,value)
alist = []
alist.insert(len(alist),10)
print(alist)

alist.insert(len(alist),20)
print(alist)


aset = {10,10,10,20,1,78,34}
print(aset)
alist = list(aset)
alist.sort()
print(alist)

