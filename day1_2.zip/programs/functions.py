# fixed arguments
def display(a,b):    # fixed arguments
    print(a,b)
display(10,20)

# default arguments
def display(a=0,b=0,c=0):
    print(a,b,c)
display()
display(10)
display(10,20)
display(10,20,30)

#keyword arguments
def display(b,a,c):
    print(a,b,c)
display(a=10,b=20,c=30)

#variable length arguments
def display(*args):
    #print(args)
    for val in args:
        print(val)
display(10,20,30,40,50,"unix","java")


def display(**kwargs):
    for key,value in kwargs.items():
        print(key,value)
display(chap1=10,chap2=20)


def display(*args,**kwargs):
    print(args)
    print(kwargs)
display(10,20,chap1=10,chap2=20)

