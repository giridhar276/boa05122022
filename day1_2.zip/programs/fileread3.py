
'''

Write a Python program to read realestate.csv and display each city and the no. of times each 
city has been repeated

SACRAMENTO      :  345 times
RANCHO CORDOVA  :   23 times
RIO LINDA       :   45 times
CITRUS HEIGHTS  :   3 times
..
.
.'''
citylist = []
import csv
with open('realestate.csv') as fobj:
    reader = csv.reader(fobj)
    # processsing
    for line in reader:
        city = line[1]
        citylist.append(city)
    # display output
    for city in set(citylist):
        print(city.ljust(20),citylist.count(city),"times")
        
        
#Write a Python program to read realestate.csv and display all the UNIQUE cities and the count of unique cities.
citylist = []
import csv
with open('realestate.csv') as fobj:
    reader = csv.reader(fobj)
    # processsing
    for line in reader:
        city = line[1]
        citylist.append(city)
    # display output
    for city in set(citylist):
        print(city)
        
        
        
        

SACRAMENTO
RANCHO CORDOVA
RIO LINDA
CITRUS HEIGHTS
..
..
..

Total on. of unique cities : xxx
