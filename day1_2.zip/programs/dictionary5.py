info = [
  {
    "name": "Meowsy",
    "species" : "cat",
    "foods": {
      "likes": ["tuna", "catnip"],
      "dislikes": ["ham", "zucchini"]
    }
  },
  {
    "name": "Barky",
    "species" : "dog",
    "foods": {
      "likes": ["bones", "carrots"],
      "dislikes": ["tuna"]
    }
  },
  {
    "name": "Purrpaws",
    "species" : "cat",
    "foods": {
      "likes": ["mice"],
      "dislikes": ["cookies"]
    }
  }
]

for item in info:
    data = list(item.values())   
    if isinstance(data[2], dict):
        subinfo = data[2].values()  # [["tuna", "catnip"],["ham", "zucchini"]]
        line = [",".join(item)  for item in subinfo]  #["tuna,catnip","ham,zucchini"]
        line = ",".join(line)  #"tuna,catnip,ham,zucchini
        finalstring = ",".join([data[0], data[0],data[1],line])
        print(finalstring)
        
        