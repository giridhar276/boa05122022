

#list
alist = [10,20,30,40,50]
alist[0] = 100
print('Updated list :',alist)



#tuple
atup = (34,23,12,8,78)


atup[2] = 340
print('Updated tuple :', atup)

# list of lists
empinfo = [['ram',30],['rao',25],['rita',23]]

for item in empinfo:
    print(item)


# list of tuples
empinfo = [('ram',30),('rao',25),('rita',23)]


