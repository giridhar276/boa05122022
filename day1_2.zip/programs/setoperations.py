

aset = {10,10,20,20,20,30,}

bset= {30,30,30,40,50}

print(aset)
print(bset)

print(aset.union(bset))

print(aset.intersection(bset))
aset.intersection_update(bset)
print(aset)

print(aset.difference(bset))

print(aset.issubset(bset))

aset.add(10)
print(aset)
aset.add(70)
print(aset)


